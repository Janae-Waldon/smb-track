export const editorTypes = {
  SUBJECT: 'subjectEditor',
  BODY: 'bodyEditor'
}
