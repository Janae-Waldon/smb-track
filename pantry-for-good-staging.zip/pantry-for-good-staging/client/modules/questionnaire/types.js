export const dragDropTypes = {
  FIELD: 'field',
  SECTION: 'section'
}
