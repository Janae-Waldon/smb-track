// flow-typed signature: 47370d221401bec823c43c3598266e26
// flow-typed version: ec28077c25/isomorphic-fetch_v2.x.x/flow_>=v0.25.x


declare module 'isomorphic-fetch' {
    declare module.exports: (input: string | Request | URL, init?: RequestOptions) => Promise<Response>;
}
